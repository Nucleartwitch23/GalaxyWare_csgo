# SimpleLoader by Wilson
This is a C# .NET Loader for beggining users to learn and adapt from.

Note: This is crackable by even the worst reverse-engineerers :P

I made this a year ago so don't expect it to be anywhere near perfect 
